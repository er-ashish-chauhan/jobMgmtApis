module.exports = {
  baseUrl: "http://localhost:5000/",
  jwtSecret: "sweat_4it34ut9049gje0943",
};
